# MyTownpedia

A Wikipedia-style platform for preserving and sharing the stories, oral history, and cultural heritage of towns worldwide, with a special focus on Araromi Obo Ekiti.

## 🌟 Features

### Core Functionality
- **Story Submission**: Users can submit stories, memories, and historical accounts about their towns
- **Admin Review System**: All submissions are reviewed and approved by administrators before going live
- **File Uploads**: Support for photos and videos to accompany stories
- **Search & Discovery**: Powerful search functionality to find stories by town, author, or content
- **User Authentication**: Secure sign-up and login system with role-based access

### Key Pages
- **Homepage**: Featured stories, search functionality, and call-to-action
- **Stories**: Browse and search all approved stories with filtering options
- **Submit Story**: Rich form for story submission with media upload
- **Gallery**: Community photo and video gallery with admin management
- **Voices of Wisdom**: Special section for elder wisdom and audio content
- **Contact**: Working contact form with admin notifications
- **Admin Panel**: Comprehensive dashboard for content management

### Admin Features
- **Content Approval**: Review, approve, or reject story submissions
- **User Management**: Manage registered users and permissions
- **Gallery Management**: Upload and organize community media
- **Contact Messages**: View and respond to contact form submissions
- **Analytics Dashboard**: Overview of site activity and content statistics

## 🛠 Technology Stack

- **Frontend**: Next.js 15, React 18, TypeScript
- **Styling**: Tailwind CSS with custom components
- **Backend**: Supabase (PostgreSQL database, authentication, storage)
- **Authentication**: Supabase Auth with custom role management
- **File Storage**: Supabase Storage for media files
- **Icons**: Lucide React
- **Notifications**: React Hot Toast
- **Deployment**: Vercel-ready configuration

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Supabase account

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/mytownpedia.git
cd mytownpedia
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up Supabase**
   - Create a new Supabase project
   - Run the SQL schema from `supabase-schema.sql` in your Supabase SQL editor
   - Configure authentication settings in Supabase dashboard

4. **Environment Configuration**
   Update `.env.local` with your Supabase credentials:
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
ADMIN_EMAIL=joshomoola@gmail.com
```

5. **Run the development server**
```bash
npm run dev
```

6. **Visit the application**
   Open [http://localhost:3000](http://localhost:3000) in your browser

### Admin Setup
- The admin user is automatically created based on the `ADMIN_EMAIL` environment variable
- First user to register with the admin email will have admin privileges
- Access admin panel at `/admin` or via the separate admin login at `/admin-login`

## 📊 Database Schema

The application uses the following main tables:

- **users**: Extended user profiles with admin flags
- **posts**: Story submissions with approval workflow
- **towns**: Community information and metadata
- **gallery**: Photo and video collections
- **wisdom_posts**: Special content from community elders
- **contact_messages**: Contact form submissions

Row Level Security (RLS) is enabled on all tables with appropriate policies for data protection.

## 🎨 Design Philosophy

### Cultural Sensitivity
- Primary focus on Araromi Obo Ekiti while welcoming global communities
- Yoruba language and Ekiti dialect consideration in design
- Inclusive design that celebrates diversity

### User Experience
- Wikipedia-inspired clean and readable design
- Mobile-first responsive approach
- Accessible navigation and content structure
- Fast loading with optimized images and lazy loading

### Content Management
- Admin-first approach with comprehensive review tools
- Easy content creation and editing workflows
- Secure file upload with automatic optimization
- SEO-friendly structure for better discoverability

## 🔧 Configuration

### Supabase Setup
1. **Authentication**: Enable email authentication in Supabase Auth settings
2. **Storage**: Create a public `media` bucket for file uploads
3. **RLS Policies**: The schema includes all necessary Row Level Security policies
4. **Functions**: Optional: Set up edge functions for advanced features

### Customization
- Update contact information in footer and contact page
- Modify the featured town information in the homepage
- Customize color scheme in `tailwind.config.js`
- Add additional languages or cultural elements as needed

## 📁 Project Structure

```
mytownpedia/
├── src/
│   ├── app/                 # Next.js app router pages
│   │   ├── admin/          # Admin panel pages
│   │   ├── auth/           # Authentication pages
│   │   ├── contact/        # Contact page
│   │   ├── gallery/        # Gallery page
│   │   ├── stories/        # Stories listing and details
│   │   ├── submit/         # Story submission
│   │   └── voices/         # Voices of Wisdom
│   ├── components/         # Reusable React components
│   │   └── layout/         # Header, Footer, Navigation
│   └── lib/                # Utilities and configurations
│       ├── auth.ts         # Authentication helpers
│       └── supabase.ts     # Supabase client and types
├── public/                 # Static assets
├── supabase-schema.sql     # Database schema
└── README.md
```

## 🚀 Deployment

### Vercel Deployment (Recommended)
1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically on every push

### Environment Variables for Production
```env
NEXT_PUBLIC_SUPABASE_URL=your_production_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_production_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_production_service_role_key
ADMIN_EMAIL=joshomoola@gmail.com
```

## 🛡 Security Features

- **Row Level Security**: All database operations are secured with RLS policies
- **Authentication**: Supabase Auth with secure password requirements
- **File Upload Security**: File type validation and size limits
- **Admin Protection**: Separate admin login and route protection
- **Input Validation**: All forms include client and server-side validation

## 🤝 Contributing

We welcome contributions to preserve more community stories! Here's how you can help:

1. **Content**: Submit stories about your town through the website
2. **Translation**: Help translate the interface for more communities
3. **Development**: Fork the repository and submit pull requests
4. **Design**: Suggest UI/UX improvements for better accessibility

### Development Guidelines
- Follow TypeScript best practices
- Use Tailwind CSS for styling consistency
- Write descriptive commit messages
- Test all functionality before submitting PRs
- Ensure accessibility standards are met

## 📞 Contact

- **Email**: joshomoola@gmail.com
- **Phone**: +234 906 717 4946
- **Location**: Araromi Obo Ekiti, Nigeria

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🌍 About Araromi Obo Ekiti

Araromi Obo Ekiti is a historic town with over 200 years of rich Yoruba culture and tradition. This platform serves as a digital preservation effort for the community's oral history, customs, and collective memory while welcoming stories from towns worldwide.

**Key Facts:**
- 🏛️ Over 200 years of documented history
- 🗣️ Primary Language: Yoruba (Ekiti dialect)
- 🌍 Diverse and inclusive community
- 📚 Rich oral traditions and cultural practices

## 🔮 Future Enhancements

- [ ] Multi-language support (Yoruba, English, others)
- [ ] Advanced search with AI-powered recommendations
- [ ] Mobile app for iOS and Android
- [ ] Audio story recording capabilities
- [ ] Community forums and discussions
- [ ] Integration with cultural institutions
- [ ] Offline reading capabilities
- [ ] Social sharing and community features

---

**Built with ❤️ for preserving our heritage and connecting communities worldwide.**
