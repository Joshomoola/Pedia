'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import type { WisdomPost } from '@/lib/supabase'
import { useAuth } from '@/lib/auth'
import { Volume2, Calendar, User, Plus, BookOpen, Heart, Loader2 } from 'lucide-react'
import Link from 'next/link'

export default function VoicesOfWisdom() {
  const { isAdmin } = useAuth()
  const [wisdomPosts, setWisdomPosts] = useState<WisdomPost[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchWisdomPosts()
  }, [])

  const fetchWisdomPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('wisdom_posts')
        .select('*')
        .order('created_at', { ascending: false })

      if (error) throw error
      setWisdomPosts(data || [])
    } catch (error) {
      console.error('Error fetching wisdom posts:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Voices of Wisdom
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Listen to the wisdom of our elders. These are the voices that have witnessed decades 
            of change, carrying stories, advice, and timeless knowledge from Araromi Obo Ekiti 
            and beyond.
          </p>
        </div>

        {/* Featured Quote */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-lg p-8 mb-12 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="text-6xl text-white opacity-50 mb-4">"</div>
            <blockquote className="text-xl md:text-2xl text-white font-medium mb-4">
              The stories of our elders are the roots from which our future grows. 
              In their voices, we find the wisdom to navigate tomorrow.
            </blockquote>
            <footer className="text-green-100">
              — Traditional Yoruba Proverb
            </footer>
          </div>
        </div>

        {/* Admin Controls */}
        {isAdmin && (
          <div className="mb-8">
            <Link
              href="/admin/wisdom/new"
              className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add New Wisdom Post
            </Link>
          </div>
        )}

        {/* Wisdom Posts */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-4 w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : wisdomPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {wisdomPosts.map((post) => (
              <article
                key={post.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="p-8">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
                      <Heart className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{post.author_name}</h3>
                      <p className="text-sm text-gray-500">Elder of the Community</p>
                    </div>
                  </div>

                  <h2 className="text-xl font-bold text-gray-900 mb-4">
                    {post.title}
                  </h2>

                  <div className="prose prose-gray max-w-none mb-6">
                    <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                      {post.content}
                    </p>
                  </div>

                  {post.audio_url && (
                    <div className="mb-6">
                      <div className="bg-gray-50 rounded-lg p-4">
                        <div className="flex items-center space-x-3 mb-3">
                          <Volume2 className="w-5 h-5 text-green-600" />
                          <span className="text-sm font-medium text-gray-700">
                            Listen to the audio recording
                          </span>
                        </div>
                        <audio
                          controls
                          className="w-full"
                          preload="metadata"
                        >
                          <source src={post.audio_url} type="audio/mpeg" />
                          <source src={post.audio_url} type="audio/wav" />
                          <source src={post.audio_url} type="audio/ogg" />
                          Your browser does not support the audio element.
                        </audio>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-sm text-gray-500 pt-4 border-t border-gray-200">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(post.created_at).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}</span>
                    </div>
                    {isAdmin && (
                      <Link
                        href={`/admin/wisdom/${post.id}/edit`}
                        className="text-green-600 hover:text-green-700 text-sm font-medium"
                      >
                        Edit
                      </Link>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              No wisdom posts yet
            </h3>
            <p className="text-gray-500 mb-6">
              This section will feature wisdom and insights from community elders.
            </p>
            {isAdmin ? (
              <Link
                href="/admin/wisdom/new"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add First Wisdom Post
              </Link>
            ) : (
              <Link
                href="/contact"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
              >
                Suggest Content
              </Link>
            )}
          </div>
        )}

        {/* About Section */}
        <div className="mt-16">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                About Voices of Wisdom
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                This special section honors the elders of our community who carry within them 
                decades of experience, traditional knowledge, and life lessons. Their voices 
                represent the living bridge between our past and future, offering guidance 
                rooted in deep wisdom and understanding.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                <div className="bg-green-50 rounded-lg p-4">
                  <h3 className="font-semibold text-green-800 mb-2">🎙️ Oral Traditions</h3>
                  <p className="text-green-700 text-sm">
                    Preserving stories, proverbs, and teachings passed down through generations.
                  </p>
                </div>
                <div className="bg-blue-50 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-800 mb-2">💡 Life Lessons</h3>
                  <p className="text-blue-700 text-sm">
                    Sharing practical wisdom gained through years of experience and observation.
                  </p>
                </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <h3 className="font-semibold text-purple-800 mb-2">🌿 Cultural Knowledge</h3>
                  <p className="text-purple-700 text-sm">
                    Maintaining connection to traditional practices, values, and customs.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}