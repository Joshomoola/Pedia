'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { useAuth } from '@/lib/auth'
import { supabase } from '@/lib/supabase'
import type { Post } from '@/lib/supabase'
import { BookOpen, Users, Heart, ArrowRight, Calendar, MapPin } from 'lucide-react'

export default function Home() {
  const { user } = useAuth()
  const [featuredStories, setFeaturedStories] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchFeaturedStories = async () => {
      try {
        const { data, error } = await supabase
          .from('posts')
          .select('*')
          .eq('status', 'approved')
          .order('created_at', { ascending: false })
          .limit(6)

        if (error) throw error
        setFeaturedStories(data || [])
      } catch (error) {
        console.error('Error fetching featured stories:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchFeaturedStories()
  }, [])

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Preserve Your Town&apos;s Story
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Share the rich history, oral traditions, and vibrant stories of Araromi Obo Ekiti 
              and towns around the world. Your story matters.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/submit"
                className="bg-yellow-500 text-black px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-400 transition-colors inline-flex items-center justify-center"
              >
                Share Your Story
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
              <Link
                href="/stories"
                className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-green-600 transition-colors inline-flex items-center justify-center"
              >
                Explore Stories
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Town Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Featured Town: Araromi Obo Ekiti
            </h2>
            <div className="w-24 h-1 bg-green-600 mx-auto mb-6"></div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              A historic town with over 200 years of rich Yoruba culture and tradition. 
              Home to diverse communities and keepers of ancient wisdom.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Rich Heritage</h3>
              <p className="text-gray-600">
                Over two centuries of oral traditions, cultural practices, and community wisdom passed down through generations.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Diverse Community</h3>
              <p className="text-gray-600">
                An inclusive town where people from different backgrounds come together, 
                primarily speaking Yoruba with the beautiful Ekiti dialect.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Living Stories</h3>
              <p className="text-gray-600">
                Every street, every elder, every family has stories that shape our identity 
                and connect us to our roots.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Stories Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Featured Stories
              </h2>
              <p className="text-lg text-gray-600">
                Discover the latest stories from our community
              </p>
            </div>
            <Link
              href="/stories"
              className="text-green-600 hover:text-green-700 font-semibold inline-flex items-center"
            >
              View All Stories
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-gray-200 rounded-lg h-64 animate-pulse"></div>
              ))}
            </div>
          ) : featuredStories.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredStories.map((story) => (
                <Link
                  key={story.id}
                  href={`/stories/${story.id}`}
                  className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-200 overflow-hidden group"
                >
                  <div className="p-6">
                    <div className="flex items-center space-x-3 mb-3">
                      <MapPin className="w-4 h-4 text-green-600 flex-shrink-0" />
                      <span className="text-sm text-green-600 font-medium">{story.town_name}</span>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-green-600 transition-colors line-clamp-2">
                      {story.title}
                    </h3>
                    <p className="text-gray-600 mb-4 line-clamp-3">
                      {story.content}
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>By {story.author_name}</span>
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(story.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No stories yet</h3>
              <p className="text-gray-500 mb-6">Be the first to share a story from your town!</p>
              {user ? (
                <Link
                  href="/submit"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
                >
                  Share Your Story
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              ) : (
                <Link
                  href="/auth"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
                >
                  Sign In to Share
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Link>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Your Story Deserves to be Told
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join our community of storytellers. Share your town&apos;s history, traditions, 
            and the moments that make your community special.
          </p>
          {user ? (
            <Link
              href="/submit"
              className="bg-yellow-500 text-black px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-400 transition-colors inline-flex items-center"
            >
              Share Your Story Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          ) : (
            <div className="space-x-4">
              <Link
                href="/auth"
                className="bg-yellow-500 text-black px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-400 transition-colors inline-flex items-center"
              >
                Join Our Community
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
