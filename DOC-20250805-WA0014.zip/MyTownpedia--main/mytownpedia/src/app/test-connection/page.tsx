'use client'

import { useState, useEffect } from 'react'
import { runConnectionTests } from '@/lib/test-connection'
import { CheckCircle, XCircle, Loader2, Database } from 'lucide-react'

export default function TestConnection() {
  const [testing, setTesting] = useState(false)
  const [results, setResults] = useState<string[]>([])
  const [success, setSuccess] = useState<boolean | null>(null)

  const runTests = async () => {
    setTesting(true)
    setResults([])
    setSuccess(null)

    // Capture console logs
    const originalLog = console.log
    const originalError = console.error
    const logs: string[] = []

    console.log = (...args) => {
      const message = args.join(' ')
      logs.push(message)
      setResults([...logs])
      originalLog(...args)
    }

    console.error = (...args) => {
      const message = '❌ ' + args.join(' ')
      logs.push(message)
      setResults([...logs])
      originalError(...args)
    }

    try {
      const result = await runConnectionTests()
      setSuccess(result)
    } catch (error) {
      setSuccess(false)
      logs.push(`❌ Test failed: ${error}`)
      setResults([...logs])
    } finally {
      // Restore original console
      console.log = originalLog
      console.error = originalError
      setTesting(false)
    }
  }

  useEffect(() => {
    runTests()
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          <div className="text-center mb-8">
            <Database className="w-16 h-16 text-blue-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Supabase Connection Test
            </h1>
            <p className="text-gray-600">
              Testing MyTownpedia&apos;s connection to Supabase backend
            </p>
          </div>

          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Test Results</h2>
              <button
                onClick={runTests}
                disabled={testing}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 inline-flex items-center"
              >
                {testing ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  'Rerun Tests'
                )}
              </button>
            </div>

            <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto max-h-96">
              {results.length === 0 && testing && (
                <div className="flex items-center">
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Running tests...
                </div>
              )}
              {results.map((result, index) => (
                <div key={index} className="mb-1">
                  {result}
                </div>
              ))}
            </div>
          </div>

          {success !== null && (
            <div className="text-center">
              {success ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <h3 className="text-lg font-semibold text-green-800">
                    ✅ All Tests Passed!
                  </h3>
                  <p className="text-green-700">
                    Your MyTownpedia is successfully connected to Supabase.
                  </p>
                </div>
              ) : (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <XCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                  <h3 className="text-lg font-semibold text-red-800">
                    ❌ Tests Failed
                  </h3>
                  <p className="text-red-700">
                    Please check your Supabase configuration and database setup.
                  </p>
                </div>
              )}
            </div>
          )}

          <div className="mt-8 text-center text-sm text-gray-500">
            <p>
              This is a development testing page. Remove this in production.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}