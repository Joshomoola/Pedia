'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import type { Post } from '@/lib/supabase'
import { Search, MapPin, Calendar, User, BookOpen, Filter } from 'lucide-react'

export default function Stories() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get('q') || ''
  
  const [stories, setStories] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [townFilter, setTownFilter] = useState('')
  const [towns, setTowns] = useState<string[]>([])

  useEffect(() => {
    fetchStories()
    fetchTowns()
  }, [])

  useEffect(() => {
    if (initialQuery) {
      handleSearch(initialQuery)
    }
  }, [initialQuery])

  const fetchStories = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false })

      if (error) throw error
      setStories(data || [])
    } catch (error) {
      console.error('Error fetching stories:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchTowns = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('town_name')
        .eq('status', 'approved')

      if (error) throw error
      
      const uniqueTowns = [...new Set(data?.map(post => post.town_name) || [])]
      setTowns(uniqueTowns.sort())
    } catch (error) {
      console.error('Error fetching towns:', error)
    }
  }

  const handleSearch = async (query: string = searchQuery) => {
    if (!query.trim() && !townFilter) {
      fetchStories()
      return
    }

    setLoading(true)
    try {
      let queryBuilder = supabase
        .from('posts')
        .select('*')
        .eq('status', 'approved')

      if (query.trim()) {
        queryBuilder = queryBuilder.or(`title.ilike.%${query}%,content.ilike.%${query}%,town_name.ilike.%${query}%,author_name.ilike.%${query}%`)
      }

      if (townFilter) {
        queryBuilder = queryBuilder.eq('town_name', townFilter)
      }

      const { data, error } = await queryBuilder.order('created_at', { ascending: false })

      if (error) throw error
      setStories(data || [])
    } catch (error) {
      console.error('Error searching stories:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSearch()
  }

  const clearFilters = () => {
    setSearchQuery('')
    setTownFilter('')
    fetchStories()
  }

  const filteredStories = stories.filter(story => {
    const matchesSearch = !searchQuery || 
      story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.town_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.author_name.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesTown = !townFilter || story.town_name === townFilter
    
    return matchesSearch && matchesTown
  })

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Community Stories
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover the rich history, traditions, and personal accounts from towns around the world. 
            Every story adds to our collective heritage.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <form onSubmit={handleSearchSubmit} className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    placeholder="Search stories, towns, or authors..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div className="md:w-64">
                <div className="relative">
                  <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <select
                    value={townFilter}
                    onChange={(e) => setTownFilter(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent appearance-none bg-white"
                  >
                    <option value="">All Towns</option>
                    {towns.map(town => (
                      <option key={town} value={town}>{town}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex space-x-2">
                <button
                  type="submit"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-medium"
                >
                  Search
                </button>
                {(searchQuery || townFilter) && (
                  <button
                    type="button"
                    onClick={clearFilters}
                    className="bg-gray-600 text-white px-4 py-3 rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>

        {/* Results Summary */}
        <div className="mb-6">
          <p className="text-gray-600">
            {loading ? 'Loading...' : `${filteredStories.length} ${filteredStories.length === 1 ? 'story' : 'stories'} found`}
            {(searchQuery || townFilter) && (
              <span>
                {searchQuery && ` for "${searchQuery}"`}
                {townFilter && ` in ${townFilter}`}
              </span>
            )}
          </p>
        </div>

        {/* Stories Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div className="h-48 bg-gray-200 animate-pulse"></div>
                <div className="p-6 space-y-3">
                  <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                  <div className="h-4 bg-gray-200 rounded animate-pulse w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded animate-pulse w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredStories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStories.map((story) => (
              <Link
                key={story.id}
                href={`/stories/${story.id}`}
                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-200 overflow-hidden group"
              >
                {/* Story Image */}
                <div className="h-48 bg-gradient-to-br from-green-100 to-blue-100 relative overflow-hidden">
                  {story.media_urls && story.media_urls.length > 0 ? (
                    <img
                      src={story.media_urls[0]}
                      alt={story.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-green-600" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300"></div>
                </div>

                {/* Story Content */}
                <div className="p-6">
                  <div className="flex items-center space-x-2 mb-3">
                    <MapPin className="w-4 h-4 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-green-600 font-medium">{story.town_name}</span>
                  </div>

                  <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-green-600 transition-colors line-clamp-2">
                    {story.title}
                  </h3>

                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {story.content}
                  </p>

                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{story.author_name}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(story.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {story.media_urls && story.media_urls.length > 1 && (
                    <div className="mt-3 text-xs text-gray-500">
                      +{story.media_urls.length - 1} more {story.media_urls.length - 1 === 1 ? 'image' : 'images'}
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              {searchQuery || townFilter ? 'No stories found' : 'No stories yet'}
            </h3>
            <p className="text-gray-500 mb-6">
              {searchQuery || townFilter 
                ? 'Try adjusting your search terms or filters'
                : 'Be the first to share a story from your town!'
              }
            </p>
            <div className="space-x-4">
              {(searchQuery || townFilter) && (
                <button
                  onClick={clearFilters}
                  className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Clear Filters
                </button>
              )}
              <Link
                href="/submit"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
              >
                Share Your Story
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}