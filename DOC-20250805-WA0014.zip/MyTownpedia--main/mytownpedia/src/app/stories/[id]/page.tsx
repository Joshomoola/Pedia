'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import type { Post } from '@/lib/supabase'
import { ArrowLeft, MapPin, Calendar, User, Share2, Image as ImageIcon, Video, Loader2 } from 'lucide-react'
import toast from 'react-hot-toast'

export default function StoryDetail() {
  const params = useParams()
  const router = useRouter()
  const storyId = params.id as string

  const [story, setStory] = useState<Post | null>(null)
  const [loading, setLoading] = useState(true)
  const [imageModalOpen, setImageModalOpen] = useState(false)
  const [selectedImage, setSelectedImage] = useState('')

  useEffect(() => {
    if (storyId) {
      fetchStory()
    }
  }, [storyId])

  const fetchStory = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('id', storyId)
        .eq('status', 'approved')
        .single()

      if (error) {
        if (error.code === 'PGRST116') {
          // Story not found
          router.push('/stories')
          toast.error('Story not found')
          return
        }
        throw error
      }

      setStory(data)
    } catch (error) {
      console.error('Error fetching story:', error)
      toast.error('Failed to load story')
      router.push('/stories')
    } finally {
      setLoading(false)
    }
  }

  const handleShare = async () => {
    const url = window.location.href
    const text = `Check out this story: ${story?.title}`

    if (navigator.share) {
      try {
        await navigator.share({
          title: story?.title,
          text,
          url
        })
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          fallbackShare(url, text)
        }
      }
    } else {
      fallbackShare(url, text)
    }
  }

  const fallbackShare = (url: string, text: string) => {
    navigator.clipboard.writeText(url).then(() => {
      toast.success('Link copied to clipboard!')
    }).catch(() => {
      toast.error('Failed to copy link')
    })
  }

  const openImageModal = (imageUrl: string) => {
    setSelectedImage(imageUrl)
    setImageModalOpen(true)
  }

  const closeImageModal = () => {
    setImageModalOpen(false)
    setSelectedImage('')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    )
  }

  if (!story) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Story Not Found</h1>
          <p className="text-gray-600 mb-6">
            The story you&apos;re looking for doesn&apos;t exist or may have been removed.
          </p>
          <Link
            href="/stories"
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Stories
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link
              href="/stories"
              className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Stories
            </Link>
            <button
              onClick={handleShare}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <Share2 className="w-5 h-5" />
              <span>Share</span>
            </button>
          </div>
        </div>
      </div>

      {/* Story Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <article className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          {/* Hero Image */}
          {story.media_urls && story.media_urls.length > 0 && (
            <div className="h-64 md:h-96 bg-gray-100 relative overflow-hidden">
              <img
                src={story.media_urls[0]}
                alt={story.title}
                className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
                onClick={() => openImageModal(story.media_urls![0])}
              />
            </div>
          )}

          <div className="p-8">
            {/* Story Meta */}
            <div className="flex flex-wrap items-center gap-4 mb-6 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-green-600" />
                <span className="text-green-600 font-medium">{story.town_name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>By {story.author_name}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>{new Date(story.created_at).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}</span>
              </div>
            </div>

            {/* Story Title */}
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 leading-tight">
              {story.title}
            </h1>

            {/* Story Content */}
            <div className="prose prose-lg max-w-none">
              <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                {story.content}
              </div>
            </div>

            {/* Media Gallery */}
            {story.media_urls && story.media_urls.length > 1 && (
              <div className="mt-12">
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Media Gallery</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {story.media_urls.slice(1).map((url, index) => {
                    const isVideo = url.includes('.mp4') || url.includes('.mov') || url.includes('.webm')
                    
                    return (
                      <div key={index} className="relative group">
                        <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                          {isVideo ? (
                            <video
                              src={url}
                              className="w-full h-full object-cover cursor-pointer"
                              controls
                            />
                          ) : (
                            <img
                              src={url}
                              alt={`${story.title} - Image ${index + 2}`}
                              className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
                              onClick={() => openImageModal(url)}
                            />
                          )}
                        </div>
                        {!isVideo && (
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-300 rounded-lg"></div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Call to Action */}
            <div className="mt-12 pt-8 border-t border-gray-200">
              <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Have a story from your town?
                </h3>
                <p className="text-gray-600 mb-4">
                  Share your own memories, traditions, and historical accounts to help preserve your community&apos;s heritage.
                </p>
                <Link
                  href="/submit"
                  className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
                >
                  Share Your Story
                </Link>
              </div>
            </div>
          </div>
        </article>
      </div>

      {/* Image Modal */}
      {imageModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={closeImageModal}
              className="absolute top-4 right-4 text-white hover:text-gray-300 z-10"
            >
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <img
              src={selectedImage}
              alt="Full size"
              className="max-w-full max-h-full object-contain"
              onClick={closeImageModal}
            />
          </div>
        </div>
      )}
    </div>
  )
}