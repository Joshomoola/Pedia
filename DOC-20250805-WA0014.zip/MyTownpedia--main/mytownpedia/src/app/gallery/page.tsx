'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import type { Gallery as GalleryItem } from '@/lib/supabase'
import { useAuth } from '@/lib/auth'
import { Plus, Edit, Star, Calendar, Image as ImageIcon, Video, Loader2, X } from 'lucide-react'
import Link from 'next/link'
import toast from 'react-hot-toast'

export default function Gallery() {
  const { user, isAdmin } = useAuth()
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState<string>('')
  const [imageModalOpen, setImageModalOpen] = useState(false)

  useEffect(() => {
    fetchGalleryItems()
  }, [])

  const fetchGalleryItems = async () => {
    try {
      const { data, error } = await supabase
        .from('gallery')
        .select('*')
        .order('is_featured', { ascending: false })
        .order('created_at', { ascending: false })

      if (error) throw error
      setGalleryItems(data || [])
    } catch (error) {
      console.error('Error fetching gallery items:', error)
    } finally {
      setLoading(false)
    }
  }

  const toggleFeatured = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('gallery')
        .update({ is_featured: !currentStatus })
        .eq('id', id)

      if (error) throw error

      setGalleryItems(items =>
        items.map(item =>
          item.id === id ? { ...item, is_featured: !currentStatus } : item
        )
      )

      toast.success(currentStatus ? 'Removed from featured' : 'Added to featured')
    } catch (error) {
      console.error('Error updating featured status:', error)
      toast.error('Failed to update featured status')
    }
  }

  const openImageModal = (imageUrl: string) => {
    setSelectedImage(imageUrl)
    setImageModalOpen(true)
  }

  const closeImageModal = () => {
    setImageModalOpen(false)
    setSelectedImage('')
  }

  const isVideo = (url: string) => {
    return url.includes('.mp4') || url.includes('.mov') || url.includes('.webm') || url.includes('.avi')
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Community Gallery
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            A visual journey through the heart of our community. Photos and videos that capture 
            the essence, culture, and daily life of Araromi Obo Ekiti and other towns.
          </p>
        </div>

        {/* Admin Controls */}
        {isAdmin && (
          <div className="mb-8 flex flex-wrap gap-4">
            <Link
              href="/admin/gallery/new"
              className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Media
            </Link>
            <Link
              href="/admin/gallery"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center"
            >
              <Edit className="w-4 h-4 mr-2" />
              Manage Gallery
            </Link>
          </div>
        )}

        {/* User Upload CTA */}
        {user && !isAdmin && (
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6 mb-8 border border-green-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Share Your Photos & Videos
                </h3>
                <p className="text-gray-600">
                  Help build our community gallery by sharing your photos and videos.
                </p>
              </div>
              <Link
                href="/submit"
                className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap"
              >
                Upload Media
              </Link>
            </div>
          </div>
        )}

        {/* Featured Items */}
        {galleryItems.some(item => item.is_featured) && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Star className="w-6 h-6 text-yellow-500 mr-2" />
              Featured
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {galleryItems
                .filter(item => item.is_featured)
                .map((item) => (
                  <div
                    key={item.id}
                    className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
                  >
                    <div className="relative">
                      <div className="aspect-video bg-gray-100 relative overflow-hidden">
                        {item.media_urls.length > 0 && (
                          isVideo(item.media_urls[0]) ? (
                            <video
                              src={item.media_urls[0]}
                              className="w-full h-full object-cover"
                              controls
                            />
                          ) : (
                            <img
                              src={item.media_urls[0]}
                              alt={item.title}
                              className="w-full h-full object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
                              onClick={() => openImageModal(item.media_urls[0])}
                            />
                          )
                        )}
                      </div>
                      <div className="absolute top-2 left-2">
                        <span className="bg-yellow-500 text-white px-2 py-1 rounded text-xs font-medium">
                          Featured
                        </span>
                      </div>
                      {isAdmin && (
                        <div className="absolute top-2 right-2">
                          <button
                            onClick={() => toggleFeatured(item.id, item.is_featured)}
                            className="bg-white/90 hover:bg-white p-1 rounded-full transition-colors"
                          >
                            <Star className="w-4 h-4 text-yellow-500" />
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                      {item.description && (
                        <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                          {item.description}
                        </p>
                      )}
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(item.created_at).toLocaleDateString()}</span>
                        </div>
                        <span>{item.media_urls.length} items</span>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* All Gallery Items */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Gallery Collection
          </h2>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                  <div className="aspect-square bg-gray-200 animate-pulse"></div>
                  <div className="p-4 space-y-2">
                    <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                    <div className="h-3 bg-gray-200 rounded animate-pulse w-3/4"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : galleryItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {galleryItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow group"
                >
                  <div className="relative">
                    <div className="aspect-square bg-gray-100 relative overflow-hidden">
                      {item.media_urls.length > 0 && (
                        isVideo(item.media_urls[0]) ? (
                          <div className="relative w-full h-full">
                            <video
                              src={item.media_urls[0]}
                              className="w-full h-full object-cover"
                              muted
                            />
                            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30">
                              <Video className="w-8 h-8 text-white" />
                            </div>
                          </div>
                        ) : (
                          <img
                            src={item.media_urls[0]}
                            alt={item.title}
                            className="w-full h-full object-cover cursor-pointer group-hover:scale-105 transition-transform duration-300"
                            onClick={() => openImageModal(item.media_urls[0])}
                          />
                        )
                      )}
                    </div>
                    
                    {item.media_urls.length > 1 && (
                      <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white px-2 py-1 rounded text-xs">
                        +{item.media_urls.length - 1}
                      </div>
                    )}

                    {isAdmin && (
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="flex space-x-1">
                          <button
                            onClick={() => toggleFeatured(item.id, item.is_featured)}
                            className={`p-1 rounded-full transition-colors ${
                              item.is_featured 
                                ? 'bg-yellow-500 text-white' 
                                : 'bg-white/90 hover:bg-white text-gray-600'
                            }`}
                          >
                            <Star className="w-4 h-4" />
                          </button>
                          <Link
                            href={`/admin/gallery/${item.id}/edit`}
                            className="bg-white/90 hover:bg-white text-gray-600 p-1 rounded-full transition-colors"
                          >
                            <Edit className="w-4 h-4" />
                          </Link>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">
                      {item.title}
                    </h3>
                    {item.description && (
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                        {item.description}
                      </p>
                    )}
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <ImageIcon className="w-3 h-3" />
                        <span>{item.media_urls.length}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <ImageIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">
                No gallery items yet
              </h3>
              <p className="text-gray-500 mb-6">
                Start building our community gallery with photos and videos.
              </p>
              <div className="space-x-4">
                {isAdmin ? (
                  <Link
                    href="/admin/gallery/new"
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors inline-flex items-center"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add First Item
                  </Link>
                ) : user ? (
                  <Link
                    href="/submit"
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Share Your Media
                  </Link>
                ) : (
                  <Link
                    href="/auth"
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Sign In to Contribute
                  </Link>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Image Modal */}
      {imageModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-6xl max-h-full">
            <button
              onClick={closeImageModal}
              className="absolute top-4 right-4 text-white hover:text-gray-300 z-10"
            >
              <X className="w-8 h-8" />
            </button>
            <img
              src={selectedImage}
              alt="Full size"
              className="max-w-full max-h-full object-contain"
              onClick={closeImageModal}
            />
          </div>
        </div>
      )}
    </div>
  )
}