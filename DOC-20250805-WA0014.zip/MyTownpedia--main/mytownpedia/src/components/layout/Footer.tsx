import Link from 'next/link'
import { Mail, Phone, MapPin, Heart } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* About Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">MT</span>
              </div>
              <span className="text-xl font-bold">MyTownpedia</span>
            </div>
            <p className="text-gray-300 text-sm">
              Preserving the rich history and stories of Araromi Obo Ekiti and towns worldwide. 
              Share your story, preserve your heritage.
            </p>
            <div className="text-sm text-gray-400">
              <p>🏛️ Over 200 years of history</p>
              <p>🗣️ Primary Language: Yoruba (Ekiti dialect)</p>
              <p>🌍 Diverse and inclusive community</p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <nav className="space-y-2">
              <Link href="/" className="block text-gray-300 hover:text-white transition-colors">
                Home
              </Link>
              <Link href="/stories" className="block text-gray-300 hover:text-white transition-colors">
                Stories
              </Link>
              <Link href="/gallery" className="block text-gray-300 hover:text-white transition-colors">
                Gallery
              </Link>
              <Link href="/voices" className="block text-gray-300 hover:text-white transition-colors">
                Voices of Wisdom
              </Link>
              <Link href="/submit" className="block text-gray-300 hover:text-white transition-colors">
                Share Your Story
              </Link>
            </nav>
          </div>

          {/* How We Help */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">How Can We Help You?</h3>
            <div className="space-y-2">
              <Link
                href="/submit"
                className="block bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-center"
              >
                Submit a Story
              </Link>
              <Link
                href="/contact?subject=partnership"
                className="block bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-center"
              >
                Partner with Us
              </Link>
              <Link
                href="/contact?subject=general"
                className="block bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors text-center"
              >
                General Inquiry
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-green-400 flex-shrink-0" />
                <a 
                  href="mailto:joshomoola@gmail.com" 
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  joshomoola@gmail.com
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-green-400 flex-shrink-0" />
                <a 
                  href="tel:+2349067174946" 
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  +234 906 717 4946
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-gray-300">
                  Araromi Obo Ekiti, Nigeria
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © {new Date().getFullYear()} MyTownpedia. Built with <Heart className="w-4 h-4 inline text-red-500" /> for preserving our heritage.
            </div>
            <div className="flex space-x-6 text-sm">
              <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-white transition-colors">
                Terms of Service
              </Link>
              <Link href="/admin-login" className="text-gray-400 hover:text-white transition-colors">
                Admin
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}