import { supabase } from './supabase'

/**
 * Test the Supabase connection and basic functionality
 */
export async function testSupabaseConnection() {
  console.log('🔗 Testing Supabase connection...')
  
  try {
    // Test 1: Basic connection
    const { data, error } = await supabase
      .from('users')
      .select('count')
      .limit(1)
    
    if (error) {
      console.error('❌ Connection failed:', error.message)
      return false
    }
    
    console.log('✅ Supabase connection successful!')
    
    // Test 2: Check if tables exist
    const tables = ['users', 'posts', 'towns', 'gallery', 'wisdom_posts', 'contact_messages']
    for (const table of tables) {
      try {
        await supabase.from(table).select('count').limit(1)
        console.log(`✅ Table '${table}' exists`)
      } catch (err) {
        console.log(`❌ Table '${table}' missing or inaccessible`)
      }
    }
    
    // Test 3: Check storage bucket
    try {
      const { data: buckets } = await supabase.storage.listBuckets()
      const mediaBucket = buckets?.find(bucket => bucket.name === 'media')
      if (mediaBucket) {
        console.log('✅ Media storage bucket exists')
      } else {
        console.log('⚠️  Media storage bucket not found')
      }
    } catch (err) {
      console.log('⚠️  Storage access limited (expected in development)')
    }
    
    return true
  } catch (error) {
    console.error('❌ Supabase connection test failed:', error)
    return false
  }
}

/**
 * Check environment variables
 */
export function checkEnvironmentVariables() {
  console.log('🔧 Checking environment variables...')
  
  const requiredVars = [
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'ADMIN_EMAIL'
  ]
  
  const missing = []
  
  for (const varName of requiredVars) {
    const value = process.env[varName]
    if (!value) {
      missing.push(varName)
      console.log(`❌ Missing: ${varName}`)
    } else {
      console.log(`✅ Found: ${varName}`)
    }
  }
  
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!serviceKey || serviceKey === 'your_service_role_key_here') {
    console.log('⚠️  SUPABASE_SERVICE_ROLE_KEY not set (required for admin functions)')
  } else {
    console.log('✅ SUPABASE_SERVICE_ROLE_KEY configured')
  }
  
  return missing.length === 0
}

/**
 * Run all connection tests
 */
export async function runConnectionTests() {
  console.log('🧪 Running MyTownpedia connection tests...\n')
  
  const envCheck = checkEnvironmentVariables()
  console.log('')
  
  if (!envCheck) {
    console.log('❌ Environment check failed. Please check your .env.local file.')
    return false
  }
  
  const connectionCheck = await testSupabaseConnection()
  console.log('')
  
  if (connectionCheck) {
    console.log('🎉 All tests passed! Your MyTownpedia is ready to go!')
  } else {
    console.log('❌ Some tests failed. Please check your Supabase configuration.')
  }
  
  return connectionCheck
}