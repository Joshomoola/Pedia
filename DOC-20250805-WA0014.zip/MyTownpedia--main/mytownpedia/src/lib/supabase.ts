import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface User {
  id: string
  email: string
  name: string
  created_at: string
  is_admin: boolean
}

export interface Town {
  id: string
  name: string
  description?: string
  created_at: string
}

export interface Post {
  id: string
  title: string
  content: string
  author_id: string
  author_name: string
  town_name: string
  status: 'pending' | 'approved' | 'rejected'
  media_urls?: string[]
  created_at: string
  updated_at: string
}

export interface Gallery {
  id: string
  title: string
  description?: string
  media_urls: string[]
  created_at: string
  is_featured: boolean
}

export interface WisdomPost {
  id: string
  title: string
  content: string
  author_name: string
  audio_url?: string
  created_at: string
}

export interface ContactMessage {
  id: string
  name: string
  email: string
  subject: string
  message: string
  created_at: string
}