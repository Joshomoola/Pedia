-- Enable necessary extensions
create extension if not exists "uuid-ossp";

-- Create custom users table (extends auth.users)
create table public.users (
  id uuid references auth.users(id) primary key,
  email text unique not null,
  name text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  is_admin boolean default false
);

-- Enable RLS on users table
alter table public.users enable row level security;

-- Users can view their own data, admins can view all
create policy "Users can view own profile" on public.users
  for select using (auth.uid() = id);

create policy "Admins can view all profiles" on public.users
  for select using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Users can update their own data
create policy "Users can update own profile" on public.users
  for update using (auth.uid() = id);

-- Create towns table
create table public.towns (
  id uuid default uuid_generate_v4() primary key,
  name text unique not null,
  description text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.towns enable row level security;

-- Anyone can view towns
create policy "Anyone can view towns" on public.towns for select using (true);

-- Only admins can insert/update towns
create policy "Admins can manage towns" on public.towns
  for all using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Create posts table
create table public.posts (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  content text not null,
  author_id uuid references public.users(id) not null,
  author_name text not null,
  town_name text not null,
  status text check (status in ('pending', 'approved', 'rejected')) default 'pending',
  media_urls text[],
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.posts enable row level security;

-- Anyone can view approved posts
create policy "Anyone can view approved posts" on public.posts
  for select using (status = 'approved');

-- Users can view their own posts
create policy "Users can view own posts" on public.posts
  for select using (auth.uid() = author_id);

-- Admins can view all posts
create policy "Admins can view all posts" on public.posts
  for select using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Authenticated users can insert posts
create policy "Authenticated users can create posts" on public.posts
  for insert with check (auth.uid() = author_id);

-- Only admins can update posts (for approval/rejection)
create policy "Admins can update posts" on public.posts
  for update using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Create gallery table
create table public.gallery (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  description text,
  media_urls text[] not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  is_featured boolean default false
);

alter table public.gallery enable row level security;

-- Anyone can view gallery
create policy "Anyone can view gallery" on public.gallery for select using (true);

-- Only admins can manage gallery
create policy "Admins can manage gallery" on public.gallery
  for all using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Create wisdom posts table
create table public.wisdom_posts (
  id uuid default uuid_generate_v4() primary key,
  title text not null,
  content text not null,
  author_name text not null,
  audio_url text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.wisdom_posts enable row level security;

-- Anyone can view wisdom posts
create policy "Anyone can view wisdom posts" on public.wisdom_posts for select using (true);

-- Only admins can manage wisdom posts
create policy "Admins can manage wisdom posts" on public.wisdom_posts
  for all using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Create contact messages table
create table public.contact_messages (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  email text not null,
  subject text not null,
  message text not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

alter table public.contact_messages enable row level security;

-- Only admins can view contact messages
create policy "Admins can view contact messages" on public.contact_messages
  for select using (
    exists (
      select 1 from public.users
      where id = auth.uid() and is_admin = true
    )
  );

-- Anyone can insert contact messages
create policy "Anyone can send contact messages" on public.contact_messages
  for insert with check (true);

-- Create function to handle new user registration
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, email, name, is_admin)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    case when new.email = 'joshomoola@gmail.com' then true else false end
  );
  return new;
end;
$$ language plpgsql security definer;

-- Create trigger for new user registration
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Insert initial town
insert into public.towns (name, description) values 
('Araromi Obo Ekiti', 'A historic town over 200 years old, rich in Yoruba culture and tradition.');

-- Create storage buckets
insert into storage.buckets (id, name, public) 
values ('media', 'media', true);

-- Create storage policy for media bucket
create policy "Anyone can view media files" on storage.objects
  for select using (bucket_id = 'media');

create policy "Authenticated users can upload media files" on storage.objects
  for insert with check (bucket_id = 'media' and auth.role() = 'authenticated');

create policy "Users can update own media files" on storage.objects
  for update using (bucket_id = 'media' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "Users can delete own media files" on storage.objects
  for delete using (bucket_id = 'media' and auth.uid()::text = (storage.foldername(name))[1]);