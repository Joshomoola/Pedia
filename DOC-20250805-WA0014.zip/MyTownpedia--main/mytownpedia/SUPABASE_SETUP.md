# Supabase Setup Guide for MyTownpedia

This guide will help you set up your Supabase backend for the MyTownpedia project.

## 🔗 Your Supabase Project Details

- **Project URL**: https://pbasqvwujjqczcleyttd.supabase.co
- **Project Ref**: pbasqvwujjqczcleyttd

## 📋 Setup Steps

### 1. Database Schema Setup

1. **Open Supabase SQL Editor**
   - Go to https://supabase.com/dashboard/project/pbasqvwujjqczcleyttd
   - Navigate to "SQL Editor" in the left sidebar
   - Click "New Query"

2. **Run the Database Schema**
   - Copy the entire contents of `supabase-schema.sql` 
   - Paste it into the SQL Editor
   - Click "Run" to execute the schema

### 2. Authentication Configuration

1. **Enable Email Authentication**
   - Go to Authentication → Settings
   - Under "Auth Providers", ensure Email is enabled
   - Set "Enable email confirmations" to your preference (recommended: disabled for development)

2. **Configure Site URL**
   - In Authentication → Settings → Site URL
   - Add your development URL: `http://localhost:3000`
   - For production, add your live domain

3. **Set Redirect URLs**
   - Add these URLs to "Redirect URLs":
     - `http://localhost:3000/auth/callback` (development)
     - `https://your-domain.com/auth/callback` (production)

### 3. Storage Setup

1. **Create Media Bucket**
   - Go to Storage section
   - Create a new bucket named `media`
   - Make it public (check "Public bucket")
   - Set file size limit to 10MB per file

2. **Configure Storage Policies**
   The schema already includes the necessary storage policies, but verify:
   - Anyone can view files in the media bucket
   - Authenticated users can upload files
   - Users can manage their own files

### 4. Row Level Security (RLS)

The schema automatically sets up RLS policies for:
- **Users**: Can view own profile, admins can view all
- **Posts**: Public can view approved posts, users can view own posts
- **Gallery**: Public viewing, admin management
- **Contact Messages**: Admins only
- **Wisdom Posts**: Public viewing, admin management

### 5. Get Your Service Role Key

1. **Access Project Settings**
   - Go to Settings → API
   - Copy the "service_role" key (keep this secret!)

2. **Update Environment Variables**
   ```env
   SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
   ```

### 6. Admin User Setup

The admin user is automatically created when someone registers with the email specified in `ADMIN_EMAIL` environment variable.

**Current Admin Email**: `joshomoola@gmail.com`

To become admin:
1. Register on the website with `joshomoola@gmail.com`
2. The system will automatically grant admin privileges
3. Access admin panel at `/admin`

### 7. Testing the Connection

1. **Start your development server**:
   ```bash
   npm run dev
   ```

2. **Test basic functionality**:
   - Visit http://localhost:3000
   - Try to sign up/sign in
   - Submit a test story
   - Check if data appears in Supabase dashboard

### 8. Verification Checklist

- [ ] Database schema executed successfully
- [ ] Authentication is working (sign up/sign in)
- [ ] File uploads work (try submitting a story with images)
- [ ] Admin user can access `/admin` panel
- [ ] Contact form submissions appear in database
- [ ] Stories require admin approval before appearing

## 🔧 Environment Variables Summary

Make sure your `.env.local` file contains:

```env
NEXT_PUBLIC_SUPABASE_URL=https://pbasqvwujjqczcleyttd.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBiYXNxdnd1ampxY3pjbGV5dHRkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM4Njg0NDQsImV4cCI6MjA2OTQ0NDQ0NH0.wUVef8_uh8IMM1RaKUtiyKUEquHUMcHH6iFc2qTO5sA
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
ADMIN_EMAIL=joshomoola@gmail.com
```

## 🚨 Security Notes

1. **Never commit your `.env.local` file** - it's already in `.gitignore`
2. **Keep your service role key secret** - it has admin privileges
3. **The anon key is safe to expose** - it's used in the frontend
4. **Use different keys for production** - don't use development keys in production

## 🐛 Troubleshooting

### Common Issues:

1. **"Invalid API key" error**
   - Check that your environment variables are correct
   - Restart your development server after changing env vars

2. **Authentication not working**
   - Verify email auth is enabled in Supabase
   - Check site URL and redirect URLs are configured

3. **File uploads failing**
   - Ensure the `media` bucket exists and is public
   - Check storage policies are in place

4. **Admin panel not accessible**
   - Register with the exact email in `ADMIN_EMAIL`
   - Check the user has `is_admin: true` in the users table

### Getting Help:

- Check Supabase logs in the dashboard
- Use browser dev tools to see network errors
- Verify database queries in Supabase SQL Editor

## 🎉 You're Ready!

Once you've completed these steps, your MyTownpedia website will be fully connected to Supabase and ready for users to start sharing their town stories!